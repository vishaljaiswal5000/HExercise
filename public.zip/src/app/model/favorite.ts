export interface Favorite {
  exerciseId: string;
  playerId: string;
}
