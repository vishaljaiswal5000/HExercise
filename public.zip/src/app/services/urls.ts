export class Urls {
  static HELIUM_EXERCISE_BODY_PARTS:string = "bodyPartList";
  static HELIUM_EXERCISE_BODY_EXERCISE:string = "bodyPart";
}
